/*====================================================================================
    EVS Codec 3GPP TS26.442 Nov 07, 2017. Version 12.10.0 / 13.5.0 / 14.1.0
  ====================================================================================*/

#ifndef __INCLUDED_DISCLAIMER_H
#define __INCLUDED_DISCLAIMER_H

#include <stdio.h>

int print_disclaimer(FILE *fPtr);




#endif /* __INCLUDED_DISCLAIMER_H */
